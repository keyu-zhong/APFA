function [fObj f]=Tubular_column_design(x)  
f = 9.8*x(1)*x(2)+2*x(1);
g(1)=1.59-x(1)*x(2);
g(2)=47.4-x(1)*x(2)*(x(1)^2+x(2)^2);
g(3)=2/x(1)-1;
g(4)=x(1)/14-1;
g(5)=2/x(1)-1;
g(6)=x(1)/8-1;
h = 0;
    constraints  =[];
    for i=1:6
        constraints=[constraints;g(i)];
    end
    fObj  = f + 10000*sum(max(constraints,0));
end