function [fObj f]=Cantilever_beam(x)  

f = 0.0624*(x(1)+x(2)+x(3)+x(4)+x(5));
g(1) = (61/x(1)^3)+(37/x(2)^3)+(19/x(3)^3)+(7/x(4)^3)+(1/x(5)^3)-1;
    constraints  =[];
    for i=1:1
        constraints=[constraints;g(i)];
    end
    fObj  = f + 10000*sum(max(constraints,0));
end