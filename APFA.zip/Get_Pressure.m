function fobj = Get_Pressure

fobj = @Fun;

    


function [z,f]=Fun(u)

% Objective
f=cost(u);
% Nonlinear inequality
  g(1)=-u(1)+0.0193*u(3);
  g(2)=-u(2)+0.00954*u(3);
  g(3)=-pi*u(3)^2*u(4)-4*pi/3*u(3)^3+1296000;
  g(4)=u(4)-240;
  z = f+1e8*sum(max(g,0));

% Apply nonlinear constraints by penalty method
% Z=f+sum_k=1^N lam_k g_k^2 *H(g_k) 
% z=f+getnonlinear(u);

function Z=getnonlinear(u)
Z=0;
% Penalty constatn
lam=10^8; lameq=10^8;
[g,geq]=constraints(u);

% Inequality constraints
for k=1:length(g),
    Z=Z+ lam*g(k)^2*getH(g(k));
end

% Equality constraints (when geq=[], length->0)
for k=1:length(geq),
   Z=Z+lameq*geq(k)^2*geteqH(geq(k));
end

% Objective functions
function z=cost(u)
z=0.6224*u(1)*u(3)*u(4)+1.7781*u(2)*u(3)^2+3.1661*u(1)^2*u(4)+19.84*u(1)^2*u(3);



% For Rosenbrock's function
% z=(1-u(1))^2+(u(2)-u(1)^2)^2+(1-u(3))^2+(1-u(4))^2 


% All constraints
function [g,geq]=constraints(x)
% Nonlinear inequality
  g(1)=-x(1)+0.0193*x(3);
  g(2)=-x(2)+0.00954*x(3);
  g(3)=-pi*x(3)^2*x(4)-4*pi/3*x(3)^3+1296000;
  g(4)=x(4)-240;

% Equality constraints
geq=[];

% Test if inequalities hold
function H=getH(g)
if g<=0, 
    H=0; 
else
    H=1; 
end

% Test if equalities hold
function H=geteqH(g)
if g==0,
    H=0;
else
    H=1; 
end
