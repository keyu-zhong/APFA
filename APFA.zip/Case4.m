clear all
clc
tic
Max_iteration=30000; % Maximum numbef of function evaluations �趨�������������
SearchAgents_no=30 ; % Number of search agents
lb =[0 0 0 0];
ub =[100 100 100 5];
dim=4;
lu = [lb .* ones(1, dim); ub .* ones(1, dim)];
p=10;

fobj=@Corrugated_bulkhead_design;
for i=1:3
    clear pop
    for in=1:SearchAgents_no
        pop(in,:)=lb+(ub-lb).*rand(1,dim);
    end
    [Best_score,Best_P,Conv_curve]=CLPFA(pop, SearchAgents_no, Max_iteration, lb, ub, dim, fobj);
    fun1(i)=Best_score;
    funx(i,:)=Best_P;
    Best_score
end
for i=1:3
    [x,z]=Corrugated_bulkhead_design(funx(i,:));
    cost(i)=z;
end
b(1,1)=min(cost);
b(1,2)=max(cost);
b(1,3)=mean(cost);
b(1,4)=std(cost,0);
c=mean(funx);
toc