function [fObj f]=piston_lever_design_problem(x)  
teta = 0.25*pi; H=x(1); B=x(2); D=x(3); X=x(4);
l2=((X*sin(teta)+H)^2+(B-X*cos(teta))^2)^0.5;
l1=((X-B)^2+H^2)^0.5;
f=0.25*pi*D^2*(l2-l1);
teta = 0.25*pi; H=x(1); B=x(2); D=x(3); X=x(4); P=1500; Q=10000; L=240; Mmax=1.8e+6;
R=abs(-X*(X*sin(teta)+H)+H*(B-X*cos(teta)))/sqrt((X-B)^2+H^2);
F=0.25*pi*P*D^2;
l2=((X*sin(teta)+H)^2+(B-X*cos(teta))^2)^0.5;
l1=((X-B)^2+H^2)^0.5;
g(1)=Q*L*cos(teta)-R*F;
g(2)=Q*(L-X)-Mmax;
g(3)=1.2*(l2-l1)-l1;
g(4)=0.5*D-B;
h = 0;
    constraints  =[];
    for i=1:4
        constraints=[constraints;g(i)];
    end
    fObj  = f + 10000*sum(max(constraints,0));
end