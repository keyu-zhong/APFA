function [fObj f]=Corrugated_bulkhead_design(x)
b=x(1); h=x(2); l=x(3); t=x(4); ABD = abs(l^2-h^2);
f = (5.885*t*(b+l))/(b+(abs(l^2-h^2))^0.5);
g(1)=-t*h*(0.4*b+l/6)+8.94*(b+(ABD)^0.5);
g(2)=-t*h^2*(0.2*b+l/12)+2.2*(8.94*(b+(ABD)^0.5))^(4/3);
g(3)=-t+0.0156*b+0.15;
g(4)=-t+0.0156*l+0.15;
g(5)=-t+1.05;
g(6)=-l+h;
h = 0;
    constraints  =[];
    for i=1:6
        constraints=[constraints;g(:,i)];
    end
    fObj  = f + 10000*sum(max(constraints,0));
end
