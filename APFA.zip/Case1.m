clear all
clc
tic
Max_iteration=30000; % Maximum numbef of function evaluations �趨�������������
SearchAgents_no=30 ; % Number of search agents
lb = [0.01 0.01 0.01 0.01 0.01];
ub = [100 100 100 100 100];
dim=5;
fobj=@Cantilever_beam;
for i=1:3
    clear pop
    for in=1:SearchAgents_no
        pop(in,:)=lb+(ub-lb).*rand(1,dim);
    end
    [Best_score,Best_P,Conv_curve]=CLPFA(pop, SearchAgents_no, Max_iteration, lb, ub, dim, fobj);
    fun1(i)=Best_score;
    funx(i,:)=Best_P;
    Best_score
end
for i=1:3
    [x,z]=Cantilever_beam(funx(i,:));
    cost(i)=z;
end
[b(1,1),index]=min(cost);
b(1,2)=max(cost);
b(1,3)=mean(cost);
b(1,4)=std(cost,0);
c=mean(funx);
Best_sol = funx(index,:);
toc