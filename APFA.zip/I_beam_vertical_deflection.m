function [fObj f]=I_beam_vertical_deflection(x)  

term1 = x(3)*(x(1)-2*x(4))^3/12; term2 = x(2)*x(4)^3/6; term3 = 2*x(2)*x(4)*((x(1)-x(4))/2)^2;
f = 5000/(term1+term2+term3);
g(1) = 2*x(2)*x(4)+x(3)*(x(1)-2*x(4))-300;
term1 = x(3)*(x(1)-2*x(4))^3;
term2 = 2*x(2)*x(4)*(4*x(4)^2+3*x(1)*(x(1)-2*x(4)));
term3 = (x(1)-2*x(4))*x(3)^3;
term4 = 2*x(4)*x(2)^3;
g(2) = ((18*x(1)*10^4)/(term1+term2))+((15*x(2)*10^3)/(term3+term4))-6;
h = 0;
    constraints  =[];
    for i=1:2
        constraints=[constraints;g(i)];
    end
    fObj  = f + 10000*sum(max(constraints,0));
end

