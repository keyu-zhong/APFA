
%%-----------------------------------------------%%
%  PATHFINDER algorithm (PFA) V2                 %
%                                                %
%  Developer                                     %
%  H. YAPICI                                     %
  
% This is a simple codes of PFA inspired by      %
% collective movements and leadership behaviours %
% of animals. The parameters can be adjusted for %
% better working.                                %
% This version is for benchmark functions.       %
%                                                %
%                                                %
%   paper: Yapici H, Cetinkaya N.                %
%               A new meta-heuristic optimizer:  % 
%               Pathfinder algorithm.            %
%               Applied Soft Computing. 2019.    %

%%-----------------------------------------------%%

function [fit_global, path_, minc] = CLPFA(pop, pop_size, max_nfes, Lb, Ub, problem_size, func_flag)

% initial population and fitness
% pop=Lb+(Ub-Lb).*rand(pop_size,problem_size);

nfes = 0;
for ik=1:pop_size
    fitness(ik) = func_flag(pop(ik,:));
    nfes = nfes + 1;
    minc(1, nfes) = min(fitness);
end

fit_old=fitness;
[fit_global, index]=min(fitness);
pop_old=pop;
global_pop=pop(index,:); 
path_=global_pop; %initial pathfinder
path__old=path_;

%%%% ���������
count = 0;
Cz = 0.8.*ones(1,problem_size);
Cz1 = 0.8.*ones(1,problem_size);

while nfes < max_nfes
            
            % the updating of parameters
            u1=(-1)+(1-(-1)).*rand(1,problem_size);
            u2=(-1)+(1-(-1)).*rand(pop_size,problem_size);
            alpha=(1)+(2-1).*rand;
            beta=(1)+(2-1).*rand;
            
            r3=rand(1,problem_size);
            r1=rand(pop_size,problem_size);
            r2=rand(pop_size,problem_size);

            A=u1.*exp(-2*nfes/max_nfes);
            eps1=(1 - nfes/(max_nfes+1)).*u2;
            
            pop=pop_old; 
            
            Mean = 0;
            for i=1:pop_size
                Mean = Mean + pop(i,:);
            end
            Mean = Mean/pop_size;
            [~,ind2]=sort(fitness);
            top1_pos = pop(ind2(1),:);top2_pos = pop(ind2(2),:);top3_pos = pop(ind2(3),:);top4_pos = pop(ind2(4),:);top5_pos = pop(ind2(5),:);
            avg_pos = (top1_pos + top2_pos + top3_pos + top4_pos)/4;
            Cz = 4*Cz.*(1-Cz); %%% logistic map
            Cz1 = 4*Cz1.*(1-Cz1); %%% logistic map
            
            for kj = 1:problem_size
                rw = (2*pi)*rand();
                if rand < 0.5
                    path_(1,kj) = path_(1,kj) + Cz(kj).*(avg_pos(kj) - Mean(kj));  %% 
                else
                    path_(1,kj) = avg_pos(kj) + cos(rw)*Cz1(kj).*(Cz(kj).*(path_(1,kj) - pop(ind2(end),kj))) ;  %% 
                end
            end
            

            % boundary checking
            Flag4ub=path_(1,:)>Ub;
            Flag4lb=path_(1,:)<Lb;
            path_(1,:)=(path_(1,:).*(~(Flag4ub+Flag4lb)))+Ub.*Flag4ub+Lb.*Flag4lb;
            path__old=path_; 
            % updating of the pathfinder
            fitx = func_flag(path_(1,:));

            [a, index] = sort(fitness);
            pop=pop(index,:);
            if fitx < a(1)
                fitness(1)=fitx;
                pop(1,:)=path_(1,:);
                if fitness(1) < fit_global
                    fit_global = fitness(1);
                    global_pop = pop(1,:);
                end
            else
                count = count + 1;
                fitness(1)=fitness(1);
                pop(1,:)=pop(1,:);
                if fitness(1) < fit_global
                    fit_global = fitness(1);
                    global_pop = pop(1,:);
                end
            end
            nfes = nfes+1;
            minc(1, nfes)=fit_global;
            Mean = mean(pop);
            % the followers movements
            for j=2:pop_size  
                fi=rand;
                if fi<=1/3
                    d=sqrt(((pop(j,:)).^2 + (pop(j-1,:)).^2));                    
                        pop(j,:) = pop(j,:) ...
                            + ((alpha).*r1(j,:)).*(global_pop(1,:)-pop(j,:)) ...
                            + ((beta).*r2(j,:)).*(pop_old(j-1,:)-pop(j,:)) + .1.*(eps1(j,:).*d./2);
                elseif fi>=2/3
                    nouse1(1)= randi(pop_size);
                    while nouse1(1)==j
                        nouse1(1)= randi(pop_size);
                    end
                    nouse1(2)= randi(pop_size);
                    while nouse1(2)==j || nouse1(2)==nouse1(1)
                        nouse1(2)= randi(pop_size);
                    end
                    nouse1(3)= randi(pop_size);
                    while nouse1(3)==j || nouse1(3)==nouse1(1) || nouse1(3)==nouse1(2)
                        nouse1(3)= randi(pop_size);
                    end
                     
                    pop(j,:) =  pop(nouse1(1),:)+rand(1,problem_size).*(pop(nouse1(2),:)-pop(nouse1(3),:));
                    
                else
                    pop(j,:)=(pop(j,:))+rand.*(global_pop(1,:)-pop_old(j,:))-randn.*(Mean-abs(pop(j,:)));
                end
                
            end
            %check the lower and upper bound for pathfinder
            for i=1:pop_size
                % boundary checking
                Flag4ub=pop(i,:)>Ub;
                Flag4lb=pop(i,:)<Lb;
                pop(i,:)=(pop(i,:).*(~(Flag4ub+Flag4lb)))+Ub.*Flag4ub+Lb.*Flag4lb;
                fitness(i) = func_flag(pop(i,:));
            end
            
            % the updating of whole population
            for i = 1 : pop_size 
                if fitness(i) < fit_old(i)
                    fit_old(i) = fitness(i);
                    pop_old(i,:) = pop(i, :);
                    if fit_old(i) < fit_global
                        fit_global = fit_old(i);
                        global_pop = pop_old(i,:);
                    end
                else
                    fit_old(i) = fit_old(i);
                    pop_old(i,:) = pop_old(i, :);
                    if fit_old(i) < fit_global
                        fit_global = fit_old(i);
                        global_pop = pop_old(i,:);
                    end
                end   
                nfes = nfes+1;
                minc(1, nfes)=fit_global;
            end
            path_=global_pop;

            disp(['CLPFA:' num2str(nfes) ...
                ' - best:' num2str(fit_global,15) ]);
end
end


function O=chaos(index,max_iter,Value)

O=zeros(1,max_iter);
x(1)=0.7;
switch index
%Chebyshev map
    case 1
for i=1:max_iter
    x(i+1)=cos(i*acos(x(i)));
    G(i)=((x(i)+1)*Value)/2;
end
    case 2
%Circle map
a=0.5;
b=0.2;
for i=1:max_iter
    x(i+1)=mod(x(i)+b-(a/(2*pi))*sin(2*pi*x(i)),1);
    G(i)=x(i)*Value;
end
    case 3
%Gauss/mouse map
for i=1:max_iter
    if x(i)==0
        x(i+1)=0;
    else
        x(i+1)=mod(1/x(i),1);
    end
    G(i)=x(i)*Value;
end

    case 4
%Iterative map
a=0.7;
for i=1:max_iter
    x(i+1)=sin((a*pi)/x(i));
    G(i)=((x(i)+1)*Value)/2;
end

    case 5
%Logistic map
a=4;
for i=1:max_iter
    x(i+1)=a*x(i)*(1-x(i));
    G(i)=x(i)*Value;
end
    case 6
%Piecewise map
P=0.4;
for i=1:max_iter
    if x(i)>=0 && x(i)<P
        x(i+1)=x(i)/P;
    end
    if x(i)>=P && x(i)<0.5
        x(i+1)=(x(i)-P)/(0.5-P);
    end
    if x(i)>=0.5 && x(i)<1-P
        x(i+1)=(1-P-x(i))/(0.5-P);
    end
    if x(i)>=1-P && x(i)<1
        x(i+1)=(1-x(i))/P;
    end    
    G(i)=x(i)*Value;
end

    case 7
%Sine map
for i=1:max_iter
     x(i+1) = sin(pi*x(i));
     G(i)=(x(i))*Value;
 end
    case 8
 %Singer map 
 u=1.07;
 for i=1:max_iter
     x(i+1) = u*(7.86*x(i)-23.31*(x(i)^2)+28.75*(x(i)^3)-13.302875*(x(i)^4));
     G(i)=(x(i))*Value;
 end
    case 9
%Sinusoidal map
 for i=1:max_iter
     x(i+1) = 2.3*x(i)^2*sin(pi*x(i));
     G(i)=(x(i))*Value;
 end
 
    case 10
 %Tent map
 x(1)=0.6;
 for i=1:max_iter
     if x(i)<0.7
         x(i+1)=x(i)/0.7;
     end
     if x(i)>=0.7
         x(i+1)=(10/3)*(1-x(i));
     end
     G(i)=(x(i))*Value;
 end

end
O=G;
end